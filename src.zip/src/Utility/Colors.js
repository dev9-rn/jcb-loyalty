export default {
    distributorColor: '#fab032',

    dealerColor: '#f58636',

    greyColor: '#ccc',

    red: 'red',

    white: '#fafafa',

    borderColor: '#ac8b9b',
    // statusbarColor: '#3c0143'
    statusbarColor: '#fff',
    actionbarColor: '#fff'
};