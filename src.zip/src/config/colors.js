export const COLORS = {
    white: '#fff',
    black: '#000',
    deepskyblue : "#00bfff",
    firebrick : "#b22222",
    palevioletred :"#db7093",
    rosybrown : "#bc8f8f",
    lightcoral : "#f08080",
    indianred :"#cd5c5c",
    steelblue:'#fab032',
    crimson:'#D34A44'
    // steelblue :"#4682b4",
    // crimson :"#dc143c"

  }